SNN.R - Cont� funcions per crear models SNN i predir amb ells.
testSNN.R - Script que prova les funcions de SNN.
fp_utils.R - Funcions relacionades amb fp i l'optimitzaci� de p
testOptimizeP.R - Script que prova l'optimitzaci� de p en divererents datasets.